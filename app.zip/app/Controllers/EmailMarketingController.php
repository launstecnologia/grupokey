<?php

namespace App\Controllers;

use App\Core\Auth;
use App\Models\EmailCampaign;
use App\Models\EmailQueue;
use App\Models\Establishment;
use App\Models\Representative;
use App\Models\User;
use App\Core\Mailer;
use App\Core\FileUpload;

class EmailMarketingController
{
    private $campaignModel;
    private $queueModel;
    private $establishmentModel;
    private $representativeModel;
    private $userModel;
    private $fileUpload;
    
    public function __construct()
    {
        $this->campaignModel = new EmailCampaign();
        $this->queueModel = new EmailQueue();
        $this->establishmentModel = new Establishment();
        $this->representativeModel = new Representative();
        $this->userModel = new User();
        $this->fileUpload = new FileUpload();
    }
    
    /**
     * Lista todas as campanhas
     */
    public function index()
    {
        Auth::requireAdmin();
        
        $filters = [
            'search' => $_GET['search'] ?? null,
            'status' => $_GET['status'] ?? null
        ];
        
        $campaigns = $this->campaignModel->getAll($filters);
        
        $data = [
            'title' => 'E-mail Marketing',
            'currentPage' => 'email-marketing',
            'campaigns' => $campaigns,
            'filters' => $filters
        ];
        
        view('email-marketing/index', $data);
    }
    
    /**
     * Exibe formulário de criação de campanha
     */
    public function create()
    {
        Auth::requireAdmin();
        
        $data = [
            'title' => 'Nova Campanha de E-mail',
            'currentPage' => 'email-marketing'
        ];
        
        view('email-marketing/create', $data);
    }
    
    /**
     * Salva nova campanha
     */
    public function store()
    {
        Auth::requireAdmin();
        
        $errors = [];
        
        // Validações
        if (empty($_POST['name']) || trim($_POST['name']) === '') {
            $errors[] = 'Nome da campanha é obrigatório';
        }
        
        if (empty($_POST['subject']) || trim($_POST['subject']) === '') {
            $errors[] = 'Assunto é obrigatório';
        }
        
        // Verificar se o body está vazio (pode estar vazio se o TinyMCE não sincronizou)
        $body = $_POST['body'] ?? '';
        // Remover tags HTML vazias e espaços
        $bodyClean = trim(strip_tags($body));
        if (empty($body) || $bodyClean === '') {
            $errors[] = 'Conteúdo do e-mail é obrigatório. Certifique-se de preencher o campo de conteúdo.';
        }
        
        if (!empty($errors)) {
            $_SESSION['error'] = implode('<br>', $errors);
            redirect(url('email-marketing/create'));
        }
        
        // Preparar dados
        $user = Auth::user();
        $representative = Auth::representative();
        
        $campaignData = [
            'name' => sanitize_input($_POST['name']),
            'subject' => sanitize_input($_POST['subject']),
            'body' => $_POST['body'], // HTML - não sanitizar
            'signature' => $_POST['signature'] ?? null,
            'status' => 'DRAFT',
            'scheduled_at' => !empty($_POST['scheduled_at']) ? $_POST['scheduled_at'] : null,
            'created_by_user_id' => $user ? $user['id'] : null,
            'created_by_representative_id' => $representative ? $representative['id'] : null
        ];
        
        try {
            $campaignId = $this->campaignModel->create($campaignData);
            
            // Processar anexos se houver
            if (isset($_FILES['attachments']) && !empty($_FILES['attachments']['name'][0])) {
                $this->handleAttachments($campaignId);
            }
            
            $_SESSION['success'] = 'Campanha criada com sucesso!';
            redirect(url('email-marketing/' . $campaignId . '/recipients'));
            
        } catch (\Exception $e) {
            write_log('Erro ao criar campanha: ' . $e->getMessage(), 'email-marketing.log');
            $_SESSION['error'] = 'Erro ao criar campanha: ' . $e->getMessage();
            redirect(url('email-marketing/create'));
        }
    }
    
    /**
     * Exibe detalhes da campanha
     */
    public function show($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        $attachments = $this->campaignModel->getAttachments($id);
        $recipients = $this->campaignModel->getRecipients($id);
        $queueStats = $this->queueModel->getStats($id);
        
        $data = [
            'title' => 'Detalhes da Campanha',
            'currentPage' => 'email-marketing',
            'campaign' => $campaign,
            'attachments' => $attachments,
            'recipients' => $recipients,
            'queueStats' => $queueStats
        ];
        
        view('email-marketing/show', $data);
    }
    
    /**
     * Exibe formulário de edição
     */
    public function edit($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        if ($campaign['status'] !== 'DRAFT' && $campaign['status'] !== 'PAUSED') {
            $_SESSION['error'] = 'Apenas campanhas em rascunho ou pausadas podem ser editadas';
            redirect(url('email-marketing/' . $id));
        }
        
        $attachments = $this->campaignModel->getAttachments($id);
        
        $data = [
            'title' => 'Editar Campanha',
            'currentPage' => 'email-marketing',
            'campaign' => $campaign,
            'attachments' => $attachments
        ];
        
        view('email-marketing/edit', $data);
    }
    
    /**
     * Atualiza campanha
     */
    public function update($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        if ($campaign['status'] !== 'DRAFT' && $campaign['status'] !== 'PAUSED') {
            $_SESSION['error'] = 'Apenas campanhas em rascunho ou pausadas podem ser editadas';
            redirect(url('email-marketing/' . $id));
        }
        
        $errors = [];
        
        if (empty($_POST['name'])) {
            $errors[] = 'Nome da campanha é obrigatório';
        }
        
        if (empty($_POST['subject'])) {
            $errors[] = 'Assunto é obrigatório';
        }
        
        if (empty($_POST['body'])) {
            $errors[] = 'Conteúdo do e-mail é obrigatório';
        }
        
        if (!empty($errors)) {
            $_SESSION['error'] = implode('<br>', $errors);
            redirect(url('email-marketing/' . $id . '/edit'));
        }
        
        $campaignData = [
            'name' => sanitize_input($_POST['name']),
            'subject' => sanitize_input($_POST['subject']),
            'body' => $_POST['body'],
            'signature' => $_POST['signature'] ?? null,
            'scheduled_at' => !empty($_POST['scheduled_at']) ? $_POST['scheduled_at'] : null
        ];
        
        try {
            $this->campaignModel->update($id, $campaignData);
            
            // Processar novos anexos se houver
            if (isset($_FILES['attachments']) && !empty($_FILES['attachments']['name'][0])) {
                $this->handleAttachments($id);
            }
            
            $_SESSION['success'] = 'Campanha atualizada com sucesso!';
            redirect(url('email-marketing/' . $id));
            
        } catch (\Exception $e) {
            write_log('Erro ao atualizar campanha: ' . $e->getMessage(), 'email-marketing.log');
            $_SESSION['error'] = 'Erro ao atualizar campanha: ' . $e->getMessage();
            redirect(url('email-marketing/' . $id . '/edit'));
        }
    }
    
    /**
     * Exibe página de seleção de destinatários
     */
    public function recipients($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        $recipients = $this->campaignModel->getRecipients($id);
        
        // Buscar opções de destinatários
        $establishments = $this->establishmentModel->getAll(['status' => 'APPROVED']);
        $representatives = $this->representativeModel->getAll(['status' => 'ACTIVE']);
        $users = $this->userModel->getAll(['status' => 'ACTIVE']);
        
        // Extrair estados e cidades únicos dos estabelecimentos
        $states = [];
        $cities = [];
        foreach ($establishments as $est) {
            if (!empty($est['uf'])) {
                $states[$est['uf']] = $est['uf'];
            }
            if (!empty($est['cidade'])) {
                $cities[$est['cidade']] = $est['cidade'];
            }
        }
        sort($states);
        sort($cities);
        
        $data = [
            'title' => 'Selecionar Destinatários',
            'currentPage' => 'email-marketing',
            'campaign' => $campaign,
            'recipients' => $recipients,
            'establishments' => $establishments,
            'representatives' => $representatives,
            'users' => $users,
            'states' => $states,
            'cities' => $cities
        ];
        
        view('email-marketing/recipients', $data);
    }
    
    /**
     * Adiciona destinatários à campanha
     */
    public function addRecipients($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        if ($campaign['status'] !== 'DRAFT' && $campaign['status'] !== 'PAUSED') {
            $_SESSION['error'] = 'Não é possível adicionar destinatários a uma campanha em envio';
            redirect(url('email-marketing/' . $id . '/recipients'));
        }
        
        $recipients = [];
        
        // Estabelecimentos
        if (!empty($_POST['establishment_ids'])) {
            $establishmentIds = is_array($_POST['establishment_ids']) ? $_POST['establishment_ids'] : explode(',', $_POST['establishment_ids']);
            foreach ($establishmentIds as $estId) {
                $establishment = $this->establishmentModel->findById($estId);
                if ($establishment && !empty($establishment['email'])) {
                    $recipients[] = [
                        'type' => 'ESTABLISHMENT',
                        'id' => $estId,
                        'email' => $establishment['email'],
                        'name' => $establishment['nome_fantasia'] ?? $establishment['nome_completo']
                    ];
                }
            }
        }
        
        // Representantes
        if (!empty($_POST['representative_ids'])) {
            $representativeIds = is_array($_POST['representative_ids']) ? $_POST['representative_ids'] : explode(',', $_POST['representative_ids']);
            foreach ($representativeIds as $repId) {
                $representative = $this->representativeModel->findById($repId);
                if ($representative && !empty($representative['email'])) {
                    $recipients[] = [
                        'type' => 'REPRESENTATIVE',
                        'id' => $repId,
                        'email' => $representative['email'],
                        'name' => $representative['nome_completo']
                    ];
                }
            }
        }
        
        // Usuários
        if (!empty($_POST['user_ids'])) {
            $userIds = is_array($_POST['user_ids']) ? $_POST['user_ids'] : explode(',', $_POST['user_ids']);
            foreach ($userIds as $userId) {
                $user = $this->userModel->findById($userId);
                if ($user && !empty($user['email'])) {
                    $recipients[] = [
                        'type' => 'USER',
                        'id' => $userId,
                        'email' => $user['email'],
                        'name' => $user['name']
                    ];
                }
            }
        }
        
        // E-mails customizados
        if (!empty($_POST['custom_emails'])) {
            $customEmails = explode("\n", $_POST['custom_emails']);
            foreach ($customEmails as $emailLine) {
                $emailLine = trim($emailLine);
                if (!empty($emailLine)) {
                    // Formato: email ou "Nome <email>"
                    if (preg_match('/^(.+?)\s*<(.+?)>$/', $emailLine, $matches)) {
                        $name = trim($matches[1]);
                        $email = trim($matches[2]);
                    } else {
                        $email = trim($emailLine);
                        $name = null;
                    }
                    
                    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        $recipients[] = [
                            'type' => 'CUSTOM',
                            'id' => null,
                            'email' => $email,
                            'name' => $name
                        ];
                    }
                }
            }
        }
        
        if (empty($recipients)) {
            $_SESSION['error'] = 'Nenhum destinatário válido foi selecionado';
            redirect(url('email-marketing/' . $id . '/recipients'));
        }
        
        try {
            $this->campaignModel->addRecipientsBatch($id, $recipients);
            $_SESSION['success'] = count($recipients) . ' destinatário(s) adicionado(s) com sucesso!';
            redirect(url('email-marketing/' . $id . '/recipients'));
            
        } catch (\Exception $e) {
            write_log('Erro ao adicionar destinatários: ' . $e->getMessage(), 'email-marketing.log');
            $_SESSION['error'] = 'Erro ao adicionar destinatários: ' . $e->getMessage();
            redirect(url('email-marketing/' . $id . '/recipients'));
        }
    }
    
    /**
     * Remove destinatário
     */
    public function removeRecipient($campaignId, $recipientId)
    {
        Auth::requireAdmin();
        
        $sql = "DELETE FROM email_campaign_recipients WHERE id = ? AND campaign_id = ?";
        $db = \App\Core\Database::getInstance();
        $db->query($sql, [$recipientId, $campaignId]);
        
        $_SESSION['success'] = 'Destinatário removido com sucesso!';
        redirect(url('email-marketing/' . $campaignId . '/recipients'));
    }
    
    /**
     * Agenda e inicia o envio da campanha
     */
    public function start($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        if ($campaign['status'] !== 'DRAFT' && $campaign['status'] !== 'PAUSED') {
            $_SESSION['error'] = 'Apenas campanhas em rascunho ou pausadas podem ser iniciadas';
            redirect(url('email-marketing/' . $id));
        }
        
        // Verificar se há destinatários
        $recipients = $this->campaignModel->getRecipients($id);
        if (empty($recipients)) {
            $_SESSION['error'] = 'Adicione destinatários antes de iniciar a campanha';
            redirect(url('email-marketing/' . $id . '/recipients'));
        }
        
        try {
            // Atualizar status da campanha
            $scheduledAt = $campaign['scheduled_at'] ?? date('Y-m-d H:i:s');
            $this->campaignModel->update($id, [
                'name' => $campaign['name'],
                'subject' => $campaign['subject'],
                'body' => $campaign['body'],
                'signature' => $campaign['signature'],
                'status' => 'SCHEDULED',
                'scheduled_at' => $scheduledAt
            ]);
            
            // Adicionar todos os destinatários pendentes à fila
            $pendingRecipients = $this->campaignModel->getRecipientsByStatus($id, 'PENDING');
            $recipientIds = array_column($pendingRecipients, 'id');
            
            if (!empty($recipientIds)) {
                $this->queueModel->addToQueue($id, $recipientIds, $scheduledAt);
            }
            
            $_SESSION['success'] = 'Campanha agendada com sucesso! O envio será processado automaticamente.';
            redirect(url('email-marketing/' . $id));
            
        } catch (\Exception $e) {
            write_log('Erro ao iniciar campanha: ' . $e->getMessage(), 'email-marketing.log');
            $_SESSION['error'] = 'Erro ao iniciar campanha: ' . $e->getMessage();
            redirect(url('email-marketing/' . $id));
        }
    }
    
    /**
     * Processa a fila de e-mails (chamado via cron ou manualmente)
     */
    public function processQueue()
    {
        // Pode ser chamado sem autenticação se for via cron
        // Mas vamos exigir autenticação para chamadas manuais
        if (!isset($_GET['cron_token']) || $_GET['cron_token'] !== env('EMAIL_QUEUE_CRON_TOKEN', 'change-this-token')) {
            Auth::requireAdmin();
        }
        
        // Configurações de rate limiting
        $batchSize = (int)($_GET['batch_size'] ?? 10); // E-mails por lote
        $delaySeconds = (int)($_GET['delay'] ?? 2); // Delay entre envios (segundos)
        
        // Buscar itens da fila
        $items = $this->queueModel->getPendingItems($batchSize);
        
        if (empty($items)) {
            echo json_encode(['message' => 'Nenhum item na fila', 'processed' => 0]);
            return;
        }
        
        $stats = [
            'processed' => 0,
            'sent' => 0,
            'failed' => 0
        ];
        
        $mailer = new Mailer();
        
        foreach ($items as $item) {
            try {
                // Buscar anexos da campanha
                $attachments = $this->campaignModel->getAttachments($item['campaign_id']);
                $attachmentPaths = [];
                
                foreach ($attachments as $attachment) {
                    if (file_exists($attachment['file_path'])) {
                        $attachmentPaths[] = [
                            'path' => $attachment['file_path'],
                            'name' => $attachment['file_name']
                        ];
                    }
                }
                
                // Preparar corpo do e-mail com assinatura
                $body = $item['body'];
                if (!empty($item['signature'])) {
                    $body .= '<br><br>' . $item['signature'];
                }
                
                // Enviar e-mail
                $mailer->send(
                    $item['email'],
                    $item['subject'],
                    $body,
                    strip_tags($body),
                    $attachmentPaths
                );
                
                // Marcar como enviado
                $this->queueModel->markAsSent($item['id']);
                
                // Atualizar status do destinatário
                $db = \App\Core\Database::getInstance();
                $db->query(
                    "UPDATE email_campaign_recipients SET status = 'SENT', sent_at = NOW() WHERE id = ?",
                    [$item['recipient_id']]
                );
                
                // Atualizar contadores da campanha
                $this->campaignModel->updateCounts($item['campaign_id'], 1, 0);
                
                $stats['sent']++;
                $stats['processed']++;
                
                // Delay entre envios
                if ($delaySeconds > 0 && $stats['processed'] < count($items)) {
                    sleep($delaySeconds);
                }
                
            } catch (\Exception $e) {
                write_log('Erro ao enviar e-mail da fila: ' . $e->getMessage(), 'email-queue.log');
                
                // Marcar como falhou
                $this->queueModel->markAsFailed($item['id'], $e->getMessage());
                
                // Atualizar status do destinatário
                $db = \App\Core\Database::getInstance();
                $db->query(
                    "UPDATE email_campaign_recipients SET status = 'FAILED', error_message = ? WHERE id = ?",
                    [$e->getMessage(), $item['recipient_id']]
                );
                
                // Atualizar contadores da campanha
                $this->campaignModel->updateCounts($item['campaign_id'], 0, 1);
                
                $stats['failed']++;
                $stats['processed']++;
            }
        }
        
        // Verificar se a campanha foi concluída
        foreach (array_unique(array_column($items, 'campaign_id')) as $campaignId) {
            $pendingCount = count($this->campaignModel->getRecipientsByStatus($campaignId, 'PENDING'));
            $queueStats = $this->queueModel->getStats($campaignId);
            
            if ($pendingCount == 0 && ($queueStats['pending'] ?? 0) == 0) {
                $this->campaignModel->updateStatus($campaignId, 'COMPLETED');
            } elseif (($queueStats['pending'] ?? 0) > 0 || ($queueStats['processing'] ?? 0) > 0) {
                $this->campaignModel->updateStatus($campaignId, 'SENDING');
            }
        }
        
        if (isset($_GET['cron_token'])) {
            echo json_encode($stats);
        } else {
            $_SESSION['success'] = "Processados: {$stats['processed']} | Enviados: {$stats['sent']} | Falhas: {$stats['failed']}";
            redirect(url('email-marketing'));
        }
    }
    
    /**
     * Pausa uma campanha
     */
    public function pause($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign || $campaign['status'] !== 'SENDING') {
            $_SESSION['error'] = 'Apenas campanhas em envio podem ser pausadas';
            redirect(url('email-marketing'));
        }
        
        $this->campaignModel->updateStatus($id, 'PAUSED');
        $_SESSION['success'] = 'Campanha pausada com sucesso!';
        redirect(url('email-marketing/' . $id));
    }
    
    /**
     * Cancela uma campanha
     */
    public function cancel($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        $this->campaignModel->updateStatus($id, 'CANCELLED');
        $_SESSION['success'] = 'Campanha cancelada com sucesso!';
        redirect(url('email-marketing/' . $id));
    }
    
    /**
     * Deleta uma campanha
     */
    public function destroy($id)
    {
        Auth::requireAdmin();
        
        $campaign = $this->campaignModel->findById($id);
        
        if (!$campaign) {
            $_SESSION['error'] = 'Campanha não encontrada';
            redirect(url('email-marketing'));
        }
        
        if ($campaign['status'] === 'SENDING') {
            $_SESSION['error'] = 'Não é possível deletar uma campanha em envio. Pause ou cancele primeiro.';
            redirect(url('email-marketing/' . $id));
        }
        
        // Deletar anexos
        $attachments = $this->campaignModel->getAttachments($id);
        foreach ($attachments as $attachment) {
            $this->campaignModel->deleteAttachment($attachment['id']);
        }
        
        $this->campaignModel->delete($id);
        $_SESSION['success'] = 'Campanha deletada com sucesso!';
        redirect(url('email-marketing'));
    }
    
    /**
     * Remove anexo
     */
    public function removeAttachment($campaignId, $attachmentId)
    {
        Auth::requireAdmin();
        
        try {
            $this->campaignModel->deleteAttachment($attachmentId);
            $_SESSION['success'] = 'Anexo removido com sucesso!';
        } catch (\Exception $e) {
            write_log('Erro ao remover anexo: ' . $e->getMessage(), 'email-marketing.log');
            $_SESSION['error'] = 'Erro ao remover anexo: ' . $e->getMessage();
        }
        
        redirect(url('email-marketing/' . $campaignId . '/edit'));
    }
    
    /**
     * Processa upload de anexos
     */
    private function handleAttachments($campaignId)
    {
        if (!isset($_FILES['attachments']) || empty($_FILES['attachments']['name'][0])) {
            return;
        }
        
        $files = $_FILES['attachments'];
        $fileCount = count($files['name']);
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file = [
                    'name' => $files['name'][$i],
                    'type' => $files['type'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'size' => $files['size'][$i]
                ];
                
                try {
                    $uploadResult = $this->fileUpload->upload($file, 'email-attachments');
                    
                    if ($uploadResult['success']) {
                        $this->campaignModel->addAttachment(
                            $campaignId,
                            $uploadResult['path'],
                            $uploadResult['original_name'],
                            $uploadResult['size'],
                            $uploadResult['type']
                        );
                    }
                } catch (\Exception $e) {
                    write_log('Erro ao fazer upload de anexo: ' . $e->getMessage(), 'email-marketing.log');
                }
            }
        }
    }
}

