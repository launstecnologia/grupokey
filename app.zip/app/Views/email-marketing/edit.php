<?php
$currentPage = 'email-marketing';
ob_start();

$campaign = $campaign ?? [];
$attachments = $attachments ?? [];
?>

<div class="pt-6 px-4">
    <div class="max-w-6xl mx-auto">
        <!-- Header -->
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
                <i class="fas fa-edit mr-2"></i>
                Editar Campanha
            </h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Edite os detalhes da campanha</p>
        </div>

        <!-- Mensagens -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="mb-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg" role="alert">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <span><?= htmlspecialchars($_SESSION['error']) ?></span>
                </div>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- Formulário -->
        <form method="POST" action="<?= url('email-marketing/' . $campaign['id']) ?>" enctype="multipart/form-data" class="space-y-6" id="campaignForm" onsubmit="return syncTinyMCE()">
            <input type="hidden" name="_method" value="PUT">
            
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                <!-- Nome da Campanha -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Nome da Campanha <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="name" required value="<?= htmlspecialchars($campaign['name'] ?? '') ?>"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                </div>

                <!-- Assunto -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Assunto do E-mail <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="subject" required value="<?= htmlspecialchars($campaign['subject'] ?? '') ?>"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                </div>

                <!-- Corpo do E-mail -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Conteúdo do E-mail <span class="text-red-500">*</span>
                    </label>
                    <textarea id="emailBody" name="body" required
                              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                              rows="15"><?= htmlspecialchars($campaign['body'] ?? '') ?></textarea>
                </div>

                <!-- Assinatura -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Assinatura
                    </label>
                    <textarea id="emailSignature" name="signature"
                              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                              rows="5"><?= htmlspecialchars($campaign['signature'] ?? '') ?></textarea>
                </div>

                <!-- Agendamento -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Agendar Envio
                    </label>
                    <input type="datetime-local" name="scheduled_at"
                           value="<?= !empty($campaign['scheduled_at']) ? date('Y-m-d\TH:i', strtotime($campaign['scheduled_at'])) : '' ?>"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                </div>

                <!-- Anexos Existentes -->
                <?php if (!empty($attachments)): ?>
                    <div class="mb-6">
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Anexos Atuais
                        </label>
                        <div class="space-y-2">
                            <?php foreach ($attachments as $attachment): ?>
                                <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                    <div class="flex items-center">
                                        <i class="fas fa-paperclip mr-2 text-gray-500 dark:text-gray-400"></i>
                                        <span class="text-sm text-gray-700 dark:text-gray-300">
                                            <?= htmlspecialchars($attachment['file_name']) ?>
                                            (<?= number_format($attachment['file_size'] / 1024, 2) ?> KB)
                                        </span>
                                    </div>
                                    <a href="<?= url('email-marketing/' . $campaign['id'] . '/attachments/' . $attachment['id'] . '/remove') ?>"
                                       class="text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300"
                                       onclick="return confirm('Deseja remover este anexo?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Novos Anexos -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Adicionar Anexos
                    </label>
                    <input type="file" name="attachments[]" multiple
                           accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                </div>
            </div>

            <!-- Botões -->
            <div class="flex justify-end gap-4">
                <a href="<?= url('email-marketing/' . $campaign['id']) ?>" class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    Cancelar
                </a>
                <button type="submit" class="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                    <i class="fas fa-save mr-2"></i>
                    Salvar Alterações
                </button>
            </div>
        </form>
    </div>
</div>

<!-- TinyMCE Editor -->
<script src="https://cdn.tiny.cloud/1/gjlth0e408dma29243jicfrfp10rbszx4ok3m98okpexllto/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
// Função para sincronizar TinyMCE antes do submit
function syncTinyMCE() {
    if (typeof tinymce !== 'undefined') {
        // Sincronizar conteúdo do editor principal
        if (tinymce.get('emailBody')) {
            tinymce.get('emailBody').save();
        }
        // Sincronizar conteúdo da assinatura
        if (tinymce.get('emailSignature')) {
            tinymce.get('emailSignature').save();
        }
    }
    return true; // Permitir submit
}

document.addEventListener('DOMContentLoaded', function() {
    tinymce.init({
        selector: '#emailBody',
        height: 400,
        menubar: false,
        plugins: [
            'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
            'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
            'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic underline strikethrough | ' +
                 'alignleft aligncenter alignright alignjustify | ' +
                 'bullist numlist outdent indent | link image | code | removeformat',
        content_style: 'body { font-family: Arial, sans-serif; font-size: 14px; }',
        branding: false,
        promotion: false,
        setup: function(editor) {
            editor.on('change', function() {
                editor.save();
            });
        }
    });

    tinymce.init({
        selector: '#emailSignature',
        height: 150,
        menubar: false,
        plugins: ['lists', 'link'],
        toolbar: 'bold italic underline | bullist numlist | link | removeformat',
        content_style: 'body { font-family: Arial, sans-serif; font-size: 14px; }',
        branding: false,
        promotion: false,
        setup: function(editor) {
            editor.on('change', function() {
                editor.save();
            });
        }
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>

