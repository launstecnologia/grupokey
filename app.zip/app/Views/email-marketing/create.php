<?php
$currentPage = 'email-marketing';
ob_start();
?>

<div class="pt-6 px-4">
    <div class="max-w-6xl mx-auto">
        <!-- Header -->
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
                <i class="fas fa-envelope mr-2"></i>
                Nova Campanha de E-mail
            </h1>
            <p class="text-gray-600 dark:text-gray-400 mt-1">Crie uma nova campanha de e-mail marketing</p>
        </div>

        <!-- Mensagens -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="mb-4 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg" role="alert">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-circle mr-2"></i>
                    <span><?= htmlspecialchars($_SESSION['error']) ?></span>
                </div>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- Formulário -->
        <form method="POST" action="<?= url('email-marketing') ?>" enctype="multipart/form-data" class="space-y-6" id="campaignForm" onsubmit="return syncTinyMCE()">
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
                <!-- Nome da Campanha -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Nome da Campanha <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="name" required
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                           placeholder="Ex: Promoção de Verão 2025">
                </div>

                <!-- Assunto -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Assunto do E-mail <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="subject" required
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                           placeholder="Ex: Confira nossas ofertas especiais!">
                </div>

                <!-- Corpo do E-mail (Editor de Texto Rico) -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Conteúdo do E-mail <span class="text-red-500">*</span>
                    </label>
                    <textarea id="emailBody" name="body" required
                              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                              rows="15"
                              placeholder="Digite o conteúdo do e-mail aqui..."></textarea>
                </div>

                <!-- Assinatura -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Assinatura (será adicionada automaticamente no final do e-mail)
                    </label>
                    <textarea id="emailSignature" name="signature"
                              class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                              rows="5"
                              placeholder="Ex: Atenciosamente,&#10;Equipe Grupo Key"></textarea>
                </div>

                <!-- Agendamento -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Agendar Envio (opcional)
                    </label>
                    <input type="datetime-local" name="scheduled_at"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        Deixe em branco para enviar imediatamente após adicionar destinatários
                    </p>
                </div>

                <!-- Anexos -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Anexos (opcional)
                    </label>
                    <input type="file" name="attachments[]" multiple
                           accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                           class="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white">
                    <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        Formatos aceitos: PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG, PNG (máx. 10MB por arquivo)
                    </p>
                </div>
            </div>

            <!-- Botões -->
            <div class="flex justify-end gap-4">
                <a href="<?= url('email-marketing') ?>" class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    Cancelar
                </a>
                <button type="submit" id="submitBtn" class="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                    <i class="fas fa-save mr-2"></i>
                    <span id="submitText">Salvar e Continuar</span>
                    <span id="submitLoading" class="hidden">
                        <i class="fas fa-spinner fa-spin mr-2"></i>
                        Salvando...
                    </span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- TinyMCE Editor -->
<script src="https://cdn.tiny.cloud/1/gjlth0e408dma29243jicfrfp10rbszx4ok3m98okpexllto/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
// Função para sincronizar TinyMCE antes do submit
function syncTinyMCE() {
    const submitBtn = document.getElementById('submitBtn');
    const submitText = document.getElementById('submitText');
    const submitLoading = document.getElementById('submitLoading');
    
    // Mostrar loading
    if (submitText) submitText.classList.add('hidden');
    if (submitLoading) submitLoading.classList.remove('hidden');
    if (submitBtn) submitBtn.disabled = true;
    
    if (typeof tinymce !== 'undefined') {
        // Sincronizar conteúdo do editor principal
        if (tinymce.get('emailBody')) {
            tinymce.get('emailBody').save();
        }
        // Sincronizar conteúdo da assinatura
        if (tinymce.get('emailSignature')) {
            tinymce.get('emailSignature').save();
        }
    }
    
    // Validar campos obrigatórios
    const name = document.querySelector('input[name="name"]')?.value?.trim();
    const subject = document.querySelector('input[name="subject"]')?.value?.trim();
    const body = document.querySelector('textarea[name="body"]')?.value?.trim();
    
    if (!name) {
        alert('Por favor, preencha o nome da campanha.');
        if (submitText) submitText.classList.remove('hidden');
        if (submitLoading) submitLoading.classList.add('hidden');
        if (submitBtn) submitBtn.disabled = false;
        return false;
    }
    
    if (!subject) {
        alert('Por favor, preencha o assunto do e-mail.');
        if (submitText) submitText.classList.remove('hidden');
        if (submitLoading) submitLoading.classList.add('hidden');
        if (submitBtn) submitBtn.disabled = false;
        return false;
    }
    
    if (!body || body === '<p></p>' || body === '<p><br></p>') {
        alert('Por favor, preencha o conteúdo do e-mail.');
        if (submitText) submitText.classList.remove('hidden');
        if (submitLoading) submitLoading.classList.add('hidden');
        if (submitBtn) submitBtn.disabled = false;
        return false;
    }
    
    return true; // Permitir submit
}

document.addEventListener('DOMContentLoaded', function() {
    tinymce.init({
        selector: '#emailBody',
        height: 400,
        menubar: false,
        plugins: [
            'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
            'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
            'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'
        ],
        toolbar: 'undo redo | formatselect | bold italic underline strikethrough | ' +
                 'alignleft aligncenter alignright alignjustify | ' +
                 'bullist numlist outdent indent | link image | code | removeformat',
        content_style: 'body { font-family: Arial, sans-serif; font-size: 14px; }',
        branding: false,
        promotion: false,
        setup: function(editor) {
            editor.on('change', function() {
                editor.save();
            });
        }
    });

    // Editor simples para assinatura
    tinymce.init({
        selector: '#emailSignature',
        height: 150,
        menubar: false,
        plugins: ['lists', 'link'],
        toolbar: 'bold italic underline | bullist numlist | link | removeformat',
        content_style: 'body { font-family: Arial, sans-serif; font-size: 14px; }',
        branding: false,
        promotion: false,
        setup: function(editor) {
            editor.on('change', function() {
                editor.save();
            });
        }
    });
});
</script>

<?php
$content = ob_get_clean();
include __DIR__ . '/../layouts/app.php';
?>

